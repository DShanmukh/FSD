// import logo from './logo.svg';
import './App.css';
import Fruits from './fruits';
function App() {
  return (
    <div className="App">
      <h2>Fruits Search</h2>
      <Fruits/>
    </div>
  );
}

export default App;
