// import React, { useEffect, useState } from 'react';
// // import { useState } from 'react';
// import { Link } from 'react-router-dom';
// // import { useEffect } from 'react';
// import axios from 'axios';
// import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import { useNavigate } from 'react-router-dom';
// import Home from './home';

// function Login(){
//     // const handleLogin = (e) => {
//     //     e.preventDefault();
//     //           toast.success("Login Successfully");
//     //         //   alert("inserted");
//     // }
//     let navigate=useNavigate();
//     let [uname,upUname] = useState('');
//     let [password,upPassword] = useState('');
//     // let password='';
//     const [logindata,Setlogindata]=useState([]);
//     const [log,Setlog]=useState(false);
//     useEffect(()=>{
//         axios.get('http://localhost:4000/getsignindata').then((response)=>{
//             Setlogindata(response.data.userdata);
//         });
//     },[])
//     function handlesubmit(e,uname,password){
//         e.preventDefault();
        
//         console.log(logindata);
//         for(let i=0;i<logindata.length;i++){
//             if(logindata[0].username==uname && logindata[0].password==password){
//                 Setlog(true);
//                 return;
//             }
//         }
//     }
//     if(log){
//         // alert("Login Successfully");
//         // return(
//         //     <Home/>
//         // )
//         navigate('/home')
//     }
//     return(
//         <div id='div'>
//             <form>
//                 <h3 id='head'>Login</h3>
//                 <label>Username :</label>
//                 <br/>
//                 <input type="text" name="name" placeholder="username"  onChange={(e)=>{upUname(e.target.value)}}/>
//                 <br/>
//                 <label>Password :</label><br/>
//                 <input type="password" name="password"  placeholder="password"  onChange={(e)=>{upPassword(e.target.value)}} />
//                 <br/><br/>
//                 <input type="submit"  id='submit' onClick={(e)=>handlesubmit(e,upUname,upPassword)}/>
//                 <ToastContainer />
//             </form>
//             <br/>
//             <p>
//                 Don't have an account? <Link to="/signin">Sign in</Link>
//             </p>
//         </div>
//     )
// }
// export default Login;

// // // Login.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';


function Login() {
    let navigate = useNavigate();
    let [uname, upUname] = useState('');
    let [password, upPassword] = useState('');
    const [logindata, Setlogindata] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:4000/getsignindata').then((response) => {
            Setlogindata(response.data.userdata);
        });
    }, []);

    function handlesubmit(e) {
        console.log(logindata);
        e.preventDefault();

        for (let i = 0; i < logindata.length; i++) {
            if (logindata[i].username === uname && logindata[i].password === password) {
                // Successful login, navigate to the home page
                toast.success("Loggedin Successfully");
                alert("logged")
                navigate('/home');
                return;
            }
        }

        // Display an error toast if login fails
        toast.error("Login failed. Please check your credentials.");
    }

    return (
        <div id='div'>
            <form>
                <h3 id='head'>Login</h3>
                <label>Username :</label>
                <br />
                <input type="text" name="name" placeholder="username" onChange={(e) => { upUname(e.target.value) }} />
                <br />
                <label>Password :</label><br />
                <input type="password" name="password" placeholder="password" onChange={(e) => { upPassword(e.target.value) }} />
                <br /><br />
                <input type="submit" id='submit' onClick={handlesubmit} />
                <ToastContainer />
            </form>
            <br />
            <p>
                Don't have an account? <Link to="/signin">Sign in</Link>
            </p>
        </div>
    );
}

export default Login;
