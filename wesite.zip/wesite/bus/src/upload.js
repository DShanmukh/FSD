import upimg from './images/upload-icon-1.png'
import keyimg from './images/simple-cartoon-keyboard.jpg'
import { Link } from 'react-router-dom';
// import Navbar from "./navbar";
// import Footer from "./footer";
import './App.css';
function Upload(){
    return(
        <div>
            {/* <Navbar/> */}
        <div className='upload'>
            <div className='upload-photo'>
                <p>Upload a Photo of the Problem</p> &nbsp; &nbsp;
                <Link to='/content'>
                <img src={upimg} alt="" className='upload-image'/>
                </Link>
            </div>
            <div className='upload-content'>
                <p>Write about your Problem</p> &nbsp; &nbsp;
                <Link to='/contentimg'>
                <img src={keyimg} alt="" className='upload-image'/>
                </Link>
            </div>
        </div>
        {/* <Footer/> */}
        </div>
    )
}
export default Upload;