import { Link } from "react-router-dom";
function Menu(){
    return(
        <div>
        <Link to="/login">Login</Link> |
        <Link to="/signin">Signin</Link> 
        </div>
    )
}
export default Menu