import './App.css';
import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Login from './login';
import Signin from './signin';
// import Menu from './menu';
import Home from './home';
import Content from './content';
import Contentimage from './content+img';
import About from './about';
import Upload from './upload';
import Footer from "./footer";
import Navbar from "./navbar";
function App() {
  return (
    <div className="App">
    <BrowserRouter>
    <Navbar/>
    {/* <Menu/> */}
        <Routes>
        <Route path="/content" element={<Content/>} />
        <Route path="/contentimg" element={<Contentimage/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/signin" element={<Signin/>} />
          <Route path="/home" element={<Home/>} />
          <Route path="/about" element={<About/>} />
          <Route path="/upload" element={<Upload/>} />
          <Route path="/" element={<Login/>} />
        </Routes>
        <Footer/>
    </BrowserRouter>
    </div>
  );
}

export default App;
