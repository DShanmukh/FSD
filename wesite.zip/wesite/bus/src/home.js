import './App.css'

function Home(){
    return( 
        <div className="home-content">
            <h1 id="head">Share Your Problem to the Government</h1>
        </div>
    )
}
export default Home;

