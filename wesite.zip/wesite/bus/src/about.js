function About(){
    return(
        <div className="about-div">
            <h2 id="about">About us</h2>
            <p>If you want to share issues regarding your surrounding that comes under government jurisdiction ,<br/> then you can use this platform as a interface to communicate with the government.</p>
            <p>This is the platform where we can share your Problem to the government by poviding some of the basic information regarding
                your address,Government department,how long have been facing the issue,and some of the information
            </p>
            <p></p>
        </div>
    )
}
export default About;