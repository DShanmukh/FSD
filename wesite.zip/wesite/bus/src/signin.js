import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Signin(){
        const [formdata,setFormdata]=useState({
            'fname':'',
            'lname':'',
            'username':'',
            'password':'',
            'Cpassword':''
        })
        const handleSignup = (e) => {
            e.preventDefault();
            console.log(formdata);
            axios.post('http://localhost:4000/signin',{formdata}).then((res)=>console.log(res.data));
              toast.success("Signin Successfully");
            //   alert("signup successfullys");
        }

    return(
        <div id='div'>
            <form onSubmit={handleSignup} action='post'>
                <h3 id='head'>Sign in</h3>
                <label>First Name :</label>
                <br/>
                <input type="text" name="fname" placeholder="firstname" id='in' onChange={(e)=>setFormdata({...formdata,fname:e.target.value})}/>
                <br/>
                <label>Last Name :</label>
                <br/>
                <input type="text" name="lname" placeholder="Lastname" id='in' onChange={(e)=>setFormdata({...formdata,lname:e.target.value})}/>
                <br/>
                <label>Username :</label>
                <br/>
                <input type="text" name="username" placeholder="username" id='in' onChange={(e)=>setFormdata({...formdata,username:e.target.value})}/>
                <br/>
                <label>Password :</label><br/>
                <input type="password" name="password" placeholder="password" id='in' onChange={(e)=>setFormdata({...formdata,password:e.target.value})}/>
                <br/>
                <label>Confirm Password :</label>
                <br/>
                <input type="password" name="Cpassword" placeholder="password" id='in' onChange={(e)=>setFormdata({...formdata,Cpassword:e.target.value})}/>
                <br/><br/>
                <input type="submit" value="signin" id='submit'/>
                <ToastContainer />
            </form>
            <br/>
            <p>
                Already have an account? <Link to="/login">Login</Link>
            </p>
        </div>
    )
}
export default Signin;

// Signup.js
