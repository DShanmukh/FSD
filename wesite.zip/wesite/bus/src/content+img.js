import axios from "axios";
import { useState } from "react";
function Contentimage(){
    const [formdata,setFormdata]=useState({
        'comments':''
    
    })
    const handle=(e)=>{
        e.preventDefault();
        console.log(formdata);
        axios.post('http://localhost:4000/addText',{formdata}).then((res)=>console.log(res.data));
        // alert("insterted");
        window.location.reload();
      }
    return(
        <div>
          
        <form onSubmit={handle}>
          <label style={{marginTop:"1%"}}>Comments :</label><br/>
          <textarea placeholder="Your message" name='comments'  onChange={(e) =>setFormdata({...formdata,comments:e.target.value})} style={{height:"200px",width:"500px"}}></textarea><br/><br/>
          <button type="submit" id='submit' className='sub' style={{margin:"5%" , background:"orange"}}>Submit</button>
        </form>
      </div>
    )
}
export default Contentimage;