import { Link } from "react-router-dom";
import React, { useState } from "react";
import logoimg from './images/connect1.jpg';
import prof from './images/profile-icon.jpg';
function Navbar(){
    const [menu,setMenu] = useState("home");
    return(

        <div id="navbar">
            <ul>
                {/* <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contactus">Contact us</a></li> */}
                <img src={logoimg} alt="" id="logo"/>
                <li onClick={()=>{setMenu("home")}}> <Link style={{textDecoration:'none'}} to='/'>Home</Link> {menu==="home"?<hr/>:<></>}</li>
                <li onClick={()=>{setMenu("about")}}><Link style={{textDecoration:'none'}} to='/about'>About</Link> {menu==="about"?<hr/>:<></>}</li>
                <li onClick={()=>{setMenu("upload")}}><Link style={{textDecoration:'none'}} to='/upload'>Upload</Link> {menu==="upload"?<hr/>:<></>}</li>
                <li id="login"><Link style={{textDecoration:'none'}} to="/login">Login</Link></li>
                <li id="login"><Link style={{textDecoration:'none'}} to="/signin">Signin</Link></li>
                <img src={prof} alt="" id="profile"/><p>kushal</p>
            </ul>
        </div>
        
    )
}
export default Navbar;

// import React, { useState } from "react";
// // import './Navbar.css' 
// import { Link } from "react-router-dom";
// // import logo from '../assests/logo.png'
// // import cart_icon from '../assests/cart_icon.png'
// const Navbar =()=>{
    
//     const [menu,setMenu] = useState("shop");
//     return(
//         <div className="navbar">
//             <div className="nav-logo">
//                 {/* <img src={logo} alt=""></img> */}
//                 <p>Fashion Flicker</p>
//             </div>
//             <ul className="nav-menu">
//                 <li onClick={()=>{setMenu("shop")}}> <Link style={{textDecoration:'none'}} to='/'>Shop</Link> {menu==="shop"?<hr/>:<></>}</li>
//                 <li onClick={()=>{setMenu("mens")}}><Link style={{textDecoration:'none'}} to='/mens'>Men</Link> {menu==="mens"?<hr/>:<></>}</li>
//                 <li onClick={()=>{setMenu("womens")}}><Link style={{textDecoration:'none'}} to='/womens'>Women</Link> {menu==="womens"?<hr/>:<></>}</li>
//                 <li onClick={()=>{setMenu("kids")}}><Link style={{textDecoration:'none'}} to='/kids'>kids</Link> {menu==="kids"?<hr/>:<></>}</li>
//             </ul>
//             <div className="nav-login-cart">
//                 <Link to='/login'><button>Login</button></Link>
//                 {/* <Link to='/cart'><img src={cart_icon} alt="" /></Link> */}
//                 <div className="nav-cart-count">0</div>

//             </div>

//         </div>
//     );
// }
// export default Navbar